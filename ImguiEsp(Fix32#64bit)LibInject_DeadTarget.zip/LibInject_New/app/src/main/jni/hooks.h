#ifndef HOOKS_H
#define HOOKS_H

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include "Call_ImGui.h"

#include "KittyMemory/MemoryPatch.h"

#include "Unity/Vector3.hpp"
#include "Unity/Vector2.hpp"
#include "Unity/Rect.h"
#include "Unity/Quaternion.h"

#include "ByNameModding/Tools.h"
#include "ByNameModding/fake_dlfcn.h"
#include "ByNameModding/Il2Cpp.h"

#include "Utils.h"
#include "bools.h"
#include "Includes/obfuscate.h"
#include "Bypass.h"
#include "Hooker.h"
#include "Esp/Call_Esp.h"
#include "Dobby/dobby.h"
#include "Includes/Call_chams.h"

#define libName "libil2cpp.so"

bool Bypass = false;
bool EnableChamsMenu = false;

#define HOOK(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOK(void, Input, void *thiz, void *ex_ab, void *ex_ac){ 
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz); 
    return;
}

int32_t (*origInput2)(void *instanceTHiz, void *param_1, bool param_2, long param_3, void *param_4, void **thiz_ptr);
int32_t myInput2(void *instanceTHiz, void *param_1, bool param_2, long param_3, void *param_4, void **thiz_ptr) {
    int32_t result = origInput2(instanceTHiz, param_1, param_2, param_3, param_4, thiz_ptr);
    if(thiz_ptr) {
        if(*thiz_ptr) {
            auto thiz = *thiz_ptr;
            ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
        }
    }
    return result;
}

bool ZombieHeadScale,ZombieScale;
float Scale1,Scale2,Scale3 = 5;
float enemy_x,enemy_y,enemy_z = 10;

void (*Player_Update) (void *player);
    void _Player_Update (void *player) {
       if (player != NULL) {           
           if (EnableEsp) {             
           if (!entityFind(player)) entitys.push_back(player);
           if (entitys.size() > 1000) {
           entitys.clear();
         		 }
           }
           if (ZombieScale){
           Transform_set_localScale(Component_get_transform(player), Vector3(enemy_x, enemy_y, enemy_z));
            } else {
            Transform_set_localScale(Component_get_transform(player), Vector3(1, 1, 1));
            }
       }
       return Player_Update (player);   
   }  


void (*Player_Ondestroy)(void *player); //No Ondestroy Get Ready To Face Crash
void _Player_Ondestroy(void *player) {
    if (player != NULL) {
        Player_Ondestroy(player);
        entitys.clear();
    }
}

void Renderingsd() {
    
    ImGuiIO &io = GetIO();
    
    time_t now = time(0);
    tm* ltm = localtime(&now);
    char buffer[80];
    strftime(buffer, 80, "%H:%M", ltm);
    std::string wt = ("%s", buffer);
    std::string watertext = "NEXTJEK [FREE VERSION]";
    if (WaterCombo[0]) {
    watertext += std::string(" | ");
    watertext += wt.c_str();
    }    
    ImVec2 cal_text = CalcTextSize(watertext.c_str());    
    waterfix.endW = cal_text.x + 20;
    waterfix.endH = cal_text.y * 2 - 6;
      
    auto bg_clr = ImColor(0, 0, 0, 140),
    line_clr = ImColor(255, 170, 55, 255),
    text_clr = ImColor(255, 255, 255, 255),
    glow_clr_first = ImColor(255, 170, 55, 125),
    glow_clr_second = ImColor(255, 170, 55, 0);
    
    auto p = GetWindowPos();
    ImVec2 position = ImVec2(menu.posW, menu.posH);    
    GetForegroundDrawList()->AddRectFilled(position, ImVec2(menu.posW + cal_text.x + 10, menu.posH + cal_text.y * 2 - 6), bg_clr);    
    GetForegroundDrawList()->AddRectFilled(position, ImVec2(menu.posW + cal_text.x + 10, menu.posH + 2), line_clr);    
    GetForegroundDrawList()->AddText(ImVec2(menu.posW + 5, menu.posH + cal_text.y / 2 - 2), text_clr, watertext.c_str());    
    GetForegroundDrawList()->AddRectFilledMultiColor(position, ImVec2(menu.posW + cal_text.x + 10, menu.posH + cal_text.y), glow_clr_first, glow_clr_first, glow_clr_second, glow_clr_second);
    
    if (openMenuuuu) {
    if (menu.ShowMouse) {
    io.MouseDrawCursor = true;
    } else {
    io.MouseDrawCursor = false;
    }
              
    SetNextWindowSize(ImVec2(800, 600), ImGuiCond_Once);    
    SetNextWindowPos(ImVec2(glWidth/2 - 327.5f, glHeight/2 - 212.5f), ImGuiCond_Once);
    
    float t = ImSaturate(menuOpenTime / 0.5f);
    PushStyleVar(ImGuiStyleVar_Alpha, t - 0.1f);
    menuOpenTime += GetIO().DeltaTime;
    
     
    if (!Begin(OBFUSCATE("@NEXTJEK"), NULL, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar)) {
    End();
    return;
    }
    
    ImVec2 Q1, Q2;
    ImDrawList* qDrawList;
    const auto& qCurrentWindowPos = GetWindowPos();
    const auto& qWindowDrawList = GetWindowDrawList();
    const auto& qBackgroundDrawList = GetBackgroundDrawList();
    const auto& qForegroundDrawList = GetForegroundDrawList();
    
    Q1 = ImVec2(35.000f, 68.000f);
    Q1.x += qCurrentWindowPos.x;
    Q1.y += qCurrentWindowPos.y;
    Q2 = ImVec2(125.000f, 70.000f);
    Q2.x += qCurrentWindowPos.x;
    Q2.y += qCurrentWindowPos.y;
    qDrawList = qWindowDrawList;
    qDrawList->AddRectFilledMultiColor(Q1, Q2, ImColor(255, 255, 255, 150), ImColor(0, 0, 0, 0), ImColor(255, 255, 255, 150), ImColor(0, 0, 0, 0));
        
    SetCursorPos(ImVec2(35, 30));
    TextColored(ImColor(255, 170, 55, 200), "NEXTJEK");
    
    SetCursorPos(ImVec2(7, 100));
    if (Button(OBFUSCATE(ICON_FA_GAMEPAD " Main Menu"), ImVec2(147.0f, 40.0f))) {		
    page1 = true;
    page2 = false;
    page3 = false;
    page4 = false;
    page5 = false;
    }
    
    SetCursorPos(ImVec2(7, 145));
    if (Button(OBFUSCATE(ICON_FA_EYE " Weapon"), ImVec2(147.0f, 40.0f))) {		
    page1 = false;
    page2 = true;
    page3 = false;
    page4 = false;
    page5 = false;
    }
    
    SetCursorPos(ImVec2(7, 190));
    if (Button(OBFUSCATE(ICON_FA_CROSSHAIRS " Extra"), ImVec2(147.0f, 40.0f))) {	
    page1 = false;
    page2 = false;
    page3 = true;
    page4 = false;
    page5 = false;	
    }
    
    SetCursorPos(ImVec2(7, 235));
    if (Button(OBFUSCATE(ICON_FA_INFINITY " ESP"), ImVec2(147.0f, 40.0f))) {		
    page1 = false;
    page2 = false;
    page3 = false;
    page4 = true;
    page5 = false;
    }
    
    SetCursorPos(ImVec2(7, 280));
    if (Button(OBFUSCATE(ICON_FA_GEAR " SETTING"), ImVec2(147.0f, 40.0f))) {		
    page1 = false;
    page2 = false;
    page3 = false;
    page4 = false;
    page5 = true;
    }
    
    time_t now = time(0);
    tm* ltm = localtime(&now);
    char buffer1[80];
    char buffer2[80];
    strftime(buffer1, 80, "%d.%m.%Y", ltm);
    strftime(buffer2, 80, "%H:%M:%S", ltm);
    
    SetCursorPos(ImVec2(45, 445));
    Text("%s", buffer2);
    
    SetCursorPos(ImVec2(35, 470));
    Text("%s", buffer1);
    
    if (page1) {		
        SetCursorPos(ImVec2(167, 20));
        BeginChild(1, ImVec2(500, 600), true);
		
		ImGui::Checkbox("Paid User", &isPaidUser);
        ImGui::Checkbox("No Ads", &isInterstitalAdsV5);
        ImGui::Checkbox("Active Battle Pass", &isBattlePass);
        if (ImGui::CollapsingHeader("ADD Money Game"))
        {
        ImGui::Checkbox("Add Money", &isMoney);
        ImGui::Checkbox("Add Gold", &isPayMoney);
        ImGui::Checkbox("Add Diamon", &isDiamond);
        }
        Separator();
        Spacing();
        if (ImGui::CollapsingHeader("ADD Token && Part"))
        {
        ImGui::Checkbox("Add Weapon Fragments", &isFragments);
        ImGui::Checkbox("Add Skin Part", &isSkinPart);
        ImGui::Checkbox("Add Lazy Token", &isLazyToken);
        ImGui::Checkbox("Add Module Token", &isModuleToken);
        ImGui::Checkbox("Add Tech Token", &isTechToken);
        ImGui::Checkbox("Add Monkey Token", &isMonkeyToken);
        ImGui::Checkbox("Add Charm", &isAddCharm);
        ImGui::Checkbox("Add Drone Part Normal", &isDronePartN);
        ImGui::Checkbox("Add Drone Part Special", &isDronePartS);
        }
        Separator();
        Spacing();
        if (ImGui::CollapsingHeader("ADD Coin &&, Coin Event"))
        {
        ImGui::Checkbox("Add Mascot Event Coins", &isRaidBox);
        ImGui::Checkbox("Add Reforge Stone", &isReforgeStone);
        ImGui::Checkbox("Add Bootcamp Point", &isBosstItem);
        ImGui::Checkbox("Add Purchase Count", &isPurchase);
        ImGui::Checkbox("Add Redeem Key", &isRedeemKey);
        ImGui::Checkbox("Add Redeem Token", &isRedeemToken);
        ImGui::Checkbox("Bought All Pack", &isBuyAllPack);
        ImGui::Checkbox("Boost Item Trial", &isAddBoostItemTrial);
        ImGui::Checkbox("Add Boost Item", &isGetValueBoostItem);
        ImGui::Checkbox("Add EXP", &isEXP);
        ImGui::Checkbox("Mision Level", &isMision);
        }
                
        EndChild();
    }
    
    
    if (page2) {		
        SetCursorPos(ImVec2(167, 20));
        BeginChild(3, ImVec2(680, 565), true);
        
        if (ImGui::CollapsingHeader("UNLOCK Weapon && Dll"))
        {
        ImGui::Checkbox("Unlock All Gun", &isUnlockAllGuns);
        ImGui::Checkbox("Unlock All Skill", &isUnlockAllSkin);
        ImGui::Checkbox("Unlock All Glove", &isUnlockAllGlove);
        ImGui::Checkbox("Unlock Drone", &isUnlockDrone);
        }
        Separator();
        Spacing();
        if (ImGui::CollapsingHeader("ADD Box"))
        {
        ImGui::Checkbox("Add Normal Box", &isNormalBox);
        ImGui::Checkbox("Add Vip Box", &isVipBox);
        ImGui::Checkbox("Add HQ Box", &isHQBox);
        ImGui::Checkbox("Add HOW Box", &isHOWBox);
        ImGui::Checkbox("Add Cybernerik Box", &isCybernetikBox);
        }
        Separator();
        Spacing();
        ImGui::Checkbox("Aimbot", &isAutoFindTarget);
        ImGui::Checkbox("God Mode", &isHealth);
        Separator();
        Spacing();
        ImGui::Checkbox("Hack Aidkit", &AidkitP);
        if(AidkitP){
        jek.AidKit.Modify();
        }else{
        jek.AidKit.Restore();
        }
        ImGui::SameLine();
        ImGui::Checkbox("Hack Granat", &GrandeP);
        if(GrandeP){
        jek.Grande.Modify();
        }else{
        jek.Grande.Restore();
        }
        Separator();
        Spacing();
        ImGui::Checkbox("Increase Wave", &isIncreaseCurrentWave);
        ImGui::Checkbox("Add Grande", &isGrande);
        ImGui::Checkbox("Add Aidkit", &isAidKit);
        ImGui::Checkbox("Weapon Level 100", &isWeapnLevel);
        ImGui::Checkbox("Unlimited Ammo", &isAmmo);
        ImGui::Checkbox("No Realod", &isreload);
        ImGui::Checkbox("High Damage", &isGetDamage);
        ImGui::Checkbox("Headshot Damage", &isDamage);
        ImGui::Checkbox("Active Damage", &isActiveDamageModifier);
        ImGui::Checkbox("Fire Speed", &isfireRate);
        ImGui::Checkbox("Damage", &isSetDamage);       
        ImGui::Checkbox("Crtitical Rate", &iscritRate);
        ImGui::Checkbox("Accuracy", &isAccuracy);
        
        if (ImGui::CollapsingHeader("Skill Menu"))
        {
        ImGui::Checkbox("Use Lighting", &isUseLightning);
        ImGui::Checkbox("Spawn Baby Pumkin", &isSpawnBabyPumpkin);
        ImGui::Checkbox("Hell Fire", &isUseHellFire);
        ImGui::Checkbox("Hades Skill", &isUseHadesSkill);
        ImGui::Checkbox("Zeus Skill", &isUseZeusSkill);
        }
        Separator();
        Spacing();
        if (ImGui::CollapsingHeader("Menu Buff"))
        {
        ImGui::Checkbox("Infinite Boost", &isBuff);
        ImGui::Checkbox("Other Infinite Boost", &isOtherBuff);
        ImGui::Checkbox("Use Infinite Boost", &isUseBuff);
        ImGui::Checkbox("Use Boost", &isboost);
      //  ImGui::Checkbox("Active Rage", &isRage);
       // ImGui::Checkbox("Active Drone", &isDroneActive);
        ImGui::Checkbox("Hatch all Egg", &isHatchAllEggs);
        }
        
        EndChild();
    }
        
    if (page3) {
        SetCursorPos(ImVec2(167, 20));
        BeginChild(4, ImVec2(800, 600), true);
		        
        ImGui::Checkbox("Kill All Zombie", &isKillAllZombieServant);
        ImGui::Checkbox("Stop All Zombie Spwan", &isStopAllSpawnZombieCoroutine);
        ImGui::Checkbox("Auto Win", &isWin);
        ImGui::Checkbox("Spawn Mascot", &isSpawnMascot);
        ImGui::Checkbox("TeleKill", &TeleKill);
        ImGui::Checkbox(OBFUSCATE("Zombie Scale"), &ZombieScale);
        if (ZombieScale) {
          ImGui::SliderFloat(OBFUSCATE("Zombie X"), &enemy_x, 0.0f, 30.0f);
          ImGui::SliderFloat(OBFUSCATE("Zombie Y"), &enemy_y, 0.0f, 30.0f);
          ImGui::SliderFloat(OBFUSCATE("Zombie Z"), &enemy_z, 0.0f, 30.0f);
        }
        ImGui::Checkbox("Fly", &Fly);
        SliderFloat("YAxis", &YAxis, 1.0f, 100.f);
        
        EndChild();
    }
    

if (page4) {
    SetCursorPos(ImVec2(167, 20));
    BeginChild(6, ImVec2(480, 466), true);
    
    Checkbox("ENABLE ESP", &EnableEsp);
    Checkbox("ESP Line", &isESPLine);
    Checkbox("ESP Line 2", &EspLine2);
    Checkbox("ESP Name", &isESPName);
    Checkbox("ESP Corner Box", &isESPCornerBox);
    Checkbox("ESP Health ", &isEspHp);
    Checkbox("ESP Health Circle ", &isEspHealth);
    Checkbox("ESP Distance", &isEspDistance);
    
    EndChild();
}


if (page5) {		
SetCursorPos(ImVec2(167, 20));
BeginChild(99, ImVec2(500, 499), true);

Text("Settings");
    Separator();
    Spacing();
            
    static int style_idx = -1;
    if (ImGui::Combo("Theme", &style_idx, "Dark\0Light\0Classic\0BlackGold\0DarkGrey\0DarkRed\0ClassicSteam\0AnotherDark\0DarkGreenBlue\0DarkReds\0DarksGrey\0AnotherDarks\0Costom\0")) {
        switch (style_idx) {
        case 0: ImGui::StyleColorsDark(); break;
        case 1: ImGui::StyleColorsLight(); break;
        case 2: ImGui::StyleColorsClassic(); break;
        case 3: ImGui::SetBlackGoldTheme(); break;
        case 4: ImGui::SetDarkGrayTheme(); break;
        case 5: ImGui::SetSoftDarkRedTheme(); break;
        case 6: ImGui::SetClassicSteamHalfLifeTheme(); break;
        case 7: ImGui::SetAnotherDarkThemeReally(); break;
        case 8: ImGui::SetDarkGreenBlueTheme(); break;
        case 9: ImGui::SetDarkRedTheme(); break;
        case 10: ImGui::SetCorporateGrayTheme(); break;
        case 11: ImGui::SetYetAnotherDarkTheme(); break;
        case 12: SetCustomStyle(); break;
        }
    }   
    EndChild();
    Separator();
    Spacing();
    
    if (ImGui::BeginTabBar(OBFUSCATE("Tab"))) {
			if (ImGui::BeginTabItem(OBFUSCATE("Visuals"))) {
				if (chamsint > 1) ImGui::Separator();
				ImGui::PushItemWidth(500);
				ImGui::Combo(OBFUSCATE("Current Chams"), &chamsint, Chams, IM_ARRAYSIZE(Chams));
				if (chamsint > 1) {
                    ImGui::PushItemWidth(45);
                    ImGui::ColorEdit3(OBFUSCATE("##Visible Color"), (float *) &visibleColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(OBFUSCATE("RGB"), &enableRainbow);
                    if (enableRainbow) {
                        visibleColor.x = redd/255;
                        visibleColor.y = greenn/255;
                        visibleColor.z = bluee/255;
                    }
				}
                if (chamsint == 6 || chamsint == 7) {
                    ImGui::ColorEdit3(OBFUSCATE("##In Wall Color"), (float *) &inWallColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(OBFUSCATE("RGB "), &enableRainbowWall);
                    if (enableRainbowWall) {
                        inWallColor.x = redd/255;
                        inWallColor.y = greenn/255;
                        inWallColor.z = bluee/255;
                    }
                    performRGBChange();
                }
                ImGui::PushItemWidth(0);
				if (chamsint > 1) ImGui::Separator();
				ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem(OBFUSCATE("Shaders"))) {
                for (std::string shader : shaders) {
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                    if (mineShader == shader) 
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0, 1, 0, 1));
                    ImGui::PushID(shader.c_str());
                    ImGui::Text("%s", shader.c_str());
                    ImGui::SameLine();
                    if (ImGui::Button(OBFUSCATE("Set"))) {
                        mineShader = shader;
                    }
                    ImGui::Separator();
                    ImGui::PopID();
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                }                
                ImGui::EndTabItem();
            }
        ImGui::EndTabBar();
        }
        }
	}
    PopStyleVar();
    End();
}

void DrawOpen() {           
    SetNextWindowSize(ImVec2(70, 70), ImGuiCond_Once);
    PushStyleVar(ImGuiStyleVar_Alpha, 0.80f);
    if (!Begin(OBFUSCATE("@imguuuui"), NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar)) {
        //End();
        return;
    }
    
    
    if (Button(OBFUSCATE(ICON_FA_BUG), ImVec2(GetContentRegionAvail().x, GetContentRegionAvail().y))) {
        openMenuuuu = !openMenuuuu;
        menuOpenTime = 0.0f;
    }
    PopStyleVar();
    End();
}

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
   
    if (!g_Initialized) {
      IMGUI_CHECKVERSION();
      ImGui::CreateContext();
      ImGuiIO& io = ImGui::GetIO();

      io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);
      ImGui_ImplOpenGL3_Init("#version 100");  
      ImGui::GetStyle().ScaleAllSizes(2.0f);
      
      io.Fonts->ClearFonts();
    ImFontConfig font_cfg;
    
    font_cfg.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();
    
    io.ConfigWindowsMoveFromTitleBarOnly = true;
    io.IniFilename = NULL;
    
    font_cfg.SizePixels = 20.0f;
    io.Fonts->AddFontFromMemoryTTF(&VerdanaBold, sizeof Font, 20.0f,&font_cfg);
    
    ImFontConfig icon_font;
    icon_font.MergeMode = true; icon_font.PixelSnapH = true;
    static const ImWchar icon_ranges[] = {ICON_MIN_FA, ICON_MAX_FA, 0x0};
    io.Fonts->AddFontFromMemoryCompressedBase85TTF(FontAwesome6_compressed_data_base85, 20.0f, &icon_font, icon_ranges);

    ImFontConfig CustomFont;
    CustomFont.FontDataOwnedByAtlas = false;

    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;
    
    Theme_Cyberpunk();
      
      
      
      g_Initialized = true;
    }

    ImGuiIO &io = ImGui::GetIO();
   
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    
    DrawOpen();
    Renderingsd(); 
    DrawESP(ImGui::GetBackgroundDrawList(), glWidth, glHeight);    
    
    ImGui::EndFrame();
    ImGui::Render();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return old_eglSwapBuffers(dpy, surface);
}

void *hack_thread(void *) {
   
     do {
        sleep(1);
    } while (!isLibraryLoaded(libName));
      
    Il2CppAttach();
    sleep(5);  
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("FetchInterstitialAd")), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("FetchRewardVideoAd")), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("ShowInterstitialAds_RewardClaimed")), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("ShowInterstitialAds"), 1), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("OnCompleteInterstitialAd")), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("ShowRewardedVideoAds"), 1), (void *) GameNoAds, (void **) &orig_GameNoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("OnVideAdsOpended"), 2), (void *) GameNoAds, (void **) &orig_GameNoAds);
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("IsInterstitialAdsAvailable")), (void *) NoAds, (void **) &get_NoAds);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("CanShowInterstitialAds"), 1), (void *) NoAds1, (void **) &get_NoAds1);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("IsRewardedVideoAvailable"), 1), (void *) NoAds2, (void **) &get_NoAds2);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("CanShowAnyInListVideoAds"), 1), (void *) NoAds2, (void **) &get_NoAds2);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("CanShowVideoAds"), 1), (void *) NoAds2, (void **) &get_NoAds2);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("CanClaimVideAdsReward"), 1), (void *) NoAds2, (void **) &get_NoAds2);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("AdsController") , OBFUSCATE("IsSegmentWaitInterval"), 1), (void *) NoAds2, (void **) &get_NoAds2);
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_IsDroneUnlocked"), 0), (void *) UnlockDronePage, (void **) &oUnlockDronePage);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("IsOwnedDrone"), 0), (void *) UnlockDronePage, (void **) &oUnlockDronePage);
   
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("Update")), (void *) UpdateMoney, (void **) &old_UpdateMoney);
    AddGameMoney = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddGameMoney"), 4); 
    AddPayMoney = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddPayMoney"), 4); 
    AddDiamond = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddDiamond"), 4); 
    AddSkinPart = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddSkinPart"), 4); 
    AddSkinPartVisual = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddSkinPartVisual"), 3);
    AddLazyEventTokens = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddLazyEventTokens"), 3);
    AddGunModuleTokens = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddGunModuleTokens"), 2); 
    AddMonkeyEventTokensFromIAP = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddMonkeyEventTokensFromIAP"), 2); 
    AddTechTokens = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddTechTokens"), 2); 
    AddRaidboxBoxAmount = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddMascotEventCoins"), 2); 
    AddReforgeStone = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddReforgeStone"), 2); 
    AddInstantForgeStone = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddInstantForgeStone"), 2); 
    AddBoostItems = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateHeroBootcampPoint"), 1); 
    AddFragments = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddFragments"), 4);
    UpdateDroneNormal = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateDroneNormalPart"), 1); 
    UpdateDroneSpecial = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateDroneSpecialPart"), 2); 
    NormalBox = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateBattlePassNormalBox"), 3); 
    VipBox = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateBattlePassVipBox"), 3); 
    HQBox = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateBattlePassHQBox"), 2); 
    HOWBox = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateBattlePassHOWBox"), 2); 
    CybernetikBox = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateBattlePassCybernetikBox"), 2); 
    AddCharm = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddCharm"), 3); 
    AddBoostItemTrial = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddBoostItemTrial"), 6); 
    GetValueBoostItem = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddBoostItems"), 4); 
    AddRedeemEventKey = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddRedeemEventKey"), 2); 
    AddRedeemEventToken = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddRedeemEventToken"), 2); 
    SetBoughtAllPackInPromoType = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("SetBoughtAllPackInPromoType"), 2);
    AddPurchaseCount = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("AddPurchaseCount"), 1);
    
    AddGrenades = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateGrenades"), 3); 
    AddAidKit = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UpdateAidKit"), 3); 
    set_XP = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("set_XP"), 1); 
    MisionLevel = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("set_levelQuestMission"), 1); 
    UnlockAllGuns = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UnlockAllGuns"), 0); 
    UnlockAllGunSkins = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UnlockAllGunSkins"), 0); 
    UnlockAllGloves = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UnlockAllGloves"), 0); 
    UnlockDrone = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("UnlockDrone"), 2); 
    BattlePassUS = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsBattlePassUS"), 0); 
    InterstitalAdsV5 = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsInterstitalAdsV5"), 0); 
    Subscription = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsSubscriptionAdsOffer"), 0); 
    ForceFree2Paid = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("ForceFree2Paid"), 0); 
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("isPaidUser"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    //Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsFreeUser"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsPiggyBankUnlock"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("CM_IsActive"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsOrganicUser"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("get_ActiveBoostBonus"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("get_hasAllBoost"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsSubscriptionAdsOffer"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsItemUnlockWithCash"), 1), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("OnwedTechValueThan"), 1), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("DTutorialManager"), OBFUSCATE("IsFinishAllCustomTutorial"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem"), OBFUSCATE("IsBoughtAllPackInPromoType"), 2), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DataNetworkTransfer"), OBFUSCATE("UserData"), OBFUSCATE("get_haveBoughtBattlePass35"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DataNetworkTransfer"), OBFUSCATE("UserData"), OBFUSCATE("IsSubscriptionAdsOffer"), 0), (void *) BooleanTrue, (void **) &oBooleanTrue);
    /*
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_IsBeaconMode")), (void *) UnlockAllMode, (void **) &old_UnlockAllMode);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_IsEndlessUnlock")), (void *) UnlockAllMode, (void **) &old_UnlockAllMode);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_IsMeleeModeUnlock")), (void *) UnlockAllMode, (void **) &old_UnlockAllMode);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_IsCrossbowPVPModeUnlock")), (void *) UnlockAllMode, (void **) &old_UnlockAllMode);
    */
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController") , OBFUSCATE("Update")), (void *) VoidUpdate, (void **) &old_VoidUpdate);
    PlusHeath = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("PlusHeath"), 1); 
    UseLightning = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("UseLightning"), 5); 
    SpawnBabyPumpkin = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("SpawnBabyPumpkin"), 1); 
    UseHellFire = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("UseHellFire"), 3); 
    UseHadesSkill = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("UseHadesSkill"), 1); 
    UseZeusSkill = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController"), OBFUSCATE("UseZeusSkill"), 2); 
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController") , OBFUSCATE("Update")), (void *) UpdatePayment, (void **) &_UpdatePayment);
    BuyBattlePassNU = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController"), OBFUSCATE("BuyBattlePassNU"), 1); 
    BuyBattlePass35 = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController"), OBFUSCATE("BuyBattlePass35"), 2); 
    BuyBattlePass = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController"), OBFUSCATE("BuyBattlePass"), 3); 
    OnPurchaseFailed = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController"), OBFUSCATE("OnPurchaseFailed"), 2); 
    PurchaseFailedHandle = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController"), OBFUSCATE("PurchaseFailedHandle"), 2); 
    /*
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("get_PercentAutoAimHitHead")), (void *) HeadShotPercent, (void **) &oHeadShotPercent);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("get_PercentFlameHitHead")), (void *) HeadShotPercent, (void **) &oHeadShotPercent);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("GetHeadShotRate"), 2), (void *) HeadShotPercent, (void **) &oHeadShotPercent);
    */
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("Update")), (void *) UpdateWeapon, (void **) &old_UpdateWeapon);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("get_curBullet")), (void *) Ammo, (void **) &old_Ammo);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("get_CritHeadshotDmg")), (void *) Damage, (void **) &old_Damage);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("HasNoReloadBoost")), (void *) reload, (void **) &old_reload);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("HasInfiniteBoost")), (void *) Buff, (void **) &old_Buff);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("OtherBuffInfiniteBullet")), (void *) OtherBuff, (void **) &old_OtherBuff);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController") , OBFUSCATE("IsUseBoostInfiniteBoost"), 1), (void *) UseBuff, (void **) &old_UseBuff);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("CheckIfPermanentBoost"), 1), (void *) UseBuff, (void **) &old_UseBuff);
    GetDamage = (void(*)(void *,float))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("SetDmgModifier"), 1); 
    set_fireRate = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("set_fireRate"), 1); 
    set_level = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("set_level"), 1); 
    set_maxAccuracy = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("set_maxAccuracy"), 1); 
    set_curAccuracy = (void(*)(void *,float))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("set_curAccuracy"), 1); 
    SetDamage = (void(*)(void *,float))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("SetDamageRate"), 1); 
    ActiveDamageModifier = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("GunController"), OBFUSCATE("ActiveDamageModifier"), 1); 
    
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("Update")), (void *) UpdateGamePlay, (void **) &old_UpdateGamePlay);
    HatchAllEggs = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("HatchAllEggs"), 1);  
    AutoFindTarget = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("AutoFindTarget"), 0);  
    SpawnMascot = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("SpawnMascot"), 2);  
    Win = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("DoWin"), 0);  
    KillAllZombieServant = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("KillAllZombieServant"), 0);  
    StopAllSpawnZombieCoroutine = (void(*)(void *,bool))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("StopAllSpawnZombieCoroutine"), 0);  
    IncreaseCurrentWave = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("IncreaseCurrentWave"), 2);  
    AddTotalReward = (void(*)(void *,int))(uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay"), OBFUSCATE("AddTotalReward"), 1);  
    /*
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("MainUIEvent") , OBFUSCATE("ReadyForRage")), (void *) Rage, (void **) &old_Rage);  
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PlayerController") , OBFUSCATE("ActivateDroneWhenRespawn")), (void *) DroneActive, (void **) &old_DroneActive);  
    */
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase") , OBFUSCATE("Update")), (void *) _Player_Update, (void **) &Player_Update);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase") , OBFUSCATE("OnDestroy")), (void *) _Player_Ondestroy, (void **) &Player_Ondestroy);
    
    get_grenadesCount = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_grenadesCount"), 0);
    get_aidKitCount = (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("get_aidKitCount"), 0);
    jek.Grande = MemoryPatch::createWithHex(get_grenadesCount, OBFUSCATE("E0E184D2C0035FD6"));
    jek.AidKit = MemoryPatch::createWithHex(get_aidKitCount, OBFUSCATE("E0E184D2C0035FD6"));
    
    auto p_eglSwapBuffers = (uintptr_t)dlsym(RTLD_NEXT, "eglSwapBuffers");
    DobbyHook((void *)p_eglSwapBuffers, (void *)hook_eglSwapBuffers, (void **)&old_eglSwapBuffers);  
    
    Pointers::LoadPointers();
    bInitDone = true;
    
    return NULL;
}

void *chams_hook(void *) {
    ProcMap mineMap;
    do {
        mineMap = KittyMemory::getLibraryMap(MineLib);
		handle = NULL;
		handle = dlopen(OBFUSCATE("libGLESv2.so"), RTLD_LAZY);
    } while (!mineMap.isValid());	
    sleep(5);  
	RenderHook();	
    return NULL;
}

#endif
