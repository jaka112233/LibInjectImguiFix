bool enableRainbow, enableRainbowWall;


const char* Chams[] = {"OFF", "Default", "Shading", "Wireframe", "Outline", "Visibility Check Outline",  "Visibility Check Shading", "Visibility Check Shading + Outline"};

