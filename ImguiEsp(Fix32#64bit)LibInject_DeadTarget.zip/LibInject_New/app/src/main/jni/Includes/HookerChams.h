void BeginDraw() {

     ImGuiIO &io = ImGui::GetIO();
     ImVec2 center = ImGui::GetMainViewport()->GetCenter();
     
     ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.8, 0.5));
     if (ImGui::Begin(OBFUSCATE("CHAMS MENU | BY NEXTJEK "))) {
		g_window = ImGui::GetCurrentWindow();
        //ImGui::Text("%.1f FPS", io.Framerate);
		if (ImGui::BeginTabBar(OBFUSCATE("Tab"))) {
			if (ImGui::BeginTabItem(OBFUSCATE("Visuals"))) {
				if (chamsint > 1) ImGui::Separator();
				ImGui::PushItemWidth(500);
				ImGui::Combo(OBFUSCATE("Current Chams"), &chamsint, Chams, IM_ARRAYSIZE(Chams));
				if (chamsint > 1) {
                    ImGui::PushItemWidth(45);
                    ImGui::ColorEdit3(OBFUSCATE("##Visible Color"), (float *) &visibleColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(OBFUSCATE("RGB"), &enableRainbow);
				}
                if (chamsint == 6 || chamsint == 7) {
                    ImGui::ColorEdit3(OBFUSCATE("##In Wall Color"), (float *) &inWallColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(OBFUSCATE("RGB "), &enableRainbowWall);
                }
                ImGui::PushItemWidth(0);
				if (chamsint > 1) ImGui::Separator();
				ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem(OBFUSCATE("Shaders"))) {
                for (std::string shader : shaders) {
                    if (mineShader == shader)
                    ImGui::PushID(shader.c_str());
                    ImGui::Text("%s", shader.c_str());
                    ImGui::SameLine();
                    if (ImGui::Button(OBFUSCATE("Set"))) {
                        mineShader = shader;
                    }
                    ImGui::Separator();
				    ImGui::PopID();
                }
                ImGui::EndTabItem();
            }
			ImGui::EndTabBar();
        }
    }
    if (enableRainbow) {
        visibleColor.x = redd/255;
        visibleColor.y = greenn/255;
        visibleColor.z = bluee/255;
    }
    if (enableRainbowWall) {
        inWallColor.x = redd/255;
        inWallColor.y = greenn/255;
        inWallColor.z = bluee/255;
    }
    performRGBChange();
    //Patches();
}
