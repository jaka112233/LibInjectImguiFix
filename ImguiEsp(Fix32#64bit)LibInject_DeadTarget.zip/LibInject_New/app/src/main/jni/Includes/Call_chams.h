#ifndef Chams_h
#define Chams_h

typedef uint32_t _DWORD;
typedef uint64_t _QWORD;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long

const char* MineLib = OBFUSCATE("libGLESv2.so");

#include "Chams.h"
#include "openGLdefine.h"
#include "RGB.h"
#include "variables.h"
//#include "HookerChams.h"

#endif
