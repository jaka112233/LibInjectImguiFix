#pragma once

#define Il2cpp "libil2cpp.so"

float FloatValue = 1;
int Value = 1, SliderValue = 1;
int isMaxSpedd,IsHightjump,IsHightjumpAir = 1;
int setr,setg,setb,setw1,setw2;
bool wireframe, glow, outline, chams, wchams, rainbow;
bool AidkitP,GrandeP = false;
bool isHealth = false;
bool isMoney,isPayMoney,isDiamond,isModuleToken,isTechToken,isRaidBox,isReforgeStone,isBosstItem,isMision,isUnlockAllGuns,isUnlockAllSkin,isUnlockAllGlove,isUnlockDrone,isDronePartN,isDronePartS,isEXP,isGrande,isAidKit;
bool isAddBoostItemTrial,isGetValueBoostItem,isAddCharm,isNormalBox,isVipBox,isHQBox,isHOWBox,isCybernetikBox,isInterstitalAdsV5,isboost;
bool isActiveDamageModifier,isFragments,isAmmo,isreload,isGetDamage,isSetDamage,isfireRate,isDamage,isBuff,isOtherBuff,isUseBuff,isSkinPart;
bool isHatchAllEggs,isAutoFindTarget,isWin,isKillAllZombieServant,isSpawnMascot,isRage,isDroneActive,MaxRank,isRedeemKey,isRedeemToken,isBuyAllPack,isIncreaseCurrentWave;
bool isAddTotalReward,isStopAllSpawnZombieCoroutine,isUnlockAllMode,isFps;
bool isUseLightning,isSpawnBabyPumpkin,isUseHellFire,isUseHadesSkill,isUseZeusSkill;
bool isLazyToken,isMonkeyToken,isPurchase,isWeapnLevel,isAccuracy,isPaidUser;
bool isCheat = true;
bool iscritRate;

uintptr_t get_grenadesCount,get_aidKitCount;

#define critRate Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("critRate"))
#define isUseCheat Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("isUseCheat"))
#define isUseCheatEndlessBoostRewardRating Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("isUseCheatEndlessBoostRewardRating"))
#define isAccountAllowCheat Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("isAccountAllowCheat"))
#define isCheatForceOverHeat Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("isCheatForceOverHeat"))
#define useCheatSaveMission Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("useCheatSaveMission"))
#define _activeBoostBonus Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("_activeBoostBonus"))
#define isRemoveBoostDamage Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("DSystem") , OBFUSCATE("isRemoveBoostDamage"))

#define minMissionFPS Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("minMissionFPS"))
#define maxMissionFPS Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("maxMissionFPS"))
#define frameCount Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("frameCount"))
#define currentFPS Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("currentFPS"))

void (*PlusHeath)(void *instance, int count);
void (*behitRadius)(void *instance, float count);
void (*UseLightning)(void *instance, bool boolean);
void (*SpawnBabyPumpkin)(void *instance, bool boolean);
void (*UseHellFire)(void *instance, bool boolean);
void (*UseHadesSkill)(void *instance, bool boolean);
void (*UseZeusSkill)(void *instance, bool boolean);
void (*old_VoidUpdate)(void *instance);
      void VoidUpdate(void *instance){
        if (instance != NULL){
         if (isHealth){
          PlusHeath(instance, 1000000);
          }
         if (isUseLightning){
          UseLightning(instance, true);
          }
         if (isSpawnBabyPumpkin){
          SpawnBabyPumpkin(instance, true);
          }
         if (isUseHellFire){
          UseHellFire(instance, true);
          }
         if (isUseHadesSkill){
          UseHadesSkill(instance, true);
          }
         if (isUseZeusSkill){
          UseZeusSkill(instance, true);
          }
     }
     return old_VoidUpdate(instance);
}

void (*GetDamage)(void *instance,  float count);
void (*SetDamage)(void *instance,  float count);
void (*set_curAccuracy)(void *instance,  float count);
void (*set_fireRate)(void *instance, int count);
void (*set_level)(void *instance, int count);
void (*set_maxAccuracy)(void *instance, int count);
void (*ActiveDamageModifier)(void *instance, bool boolean);
void (*old_UpdateWeapon)(void *instance);
void UpdateWeapon(void *instance){
        if (instance != NULL){
         if (isGetDamage){
          GetDamage(instance, 10000000); // value
          }
         if (isSetDamage){
          SetDamage(instance, 10000000); // value
          }
         if (isfireRate){
          set_fireRate(instance, 5); // value
          }
         if (isWeapnLevel){
          set_level(instance, 100); // value
          }
         if (isAccuracy){
          set_curAccuracy(instance, 0); // value
          set_maxAccuracy(instance, 0); // value
          }
         if (isActiveDamageModifier){
          ActiveDamageModifier(instance, true); // value
          }
     }
     return old_UpdateWeapon(instance);
}

void (*AddGameMoney)(void *instance, int count);
void (*AddPayMoney)(void *instance, int count);
void (*AddDiamond)(void *instance, int count);
void (*AddSkinPart)(void *instance, int count);
void (*AddSkinPartVisual)(void *instance, int count);
void (*AddLazyEventTokens)(void *instance, int count);
void (*AddGunModuleTokens)(void *instance, int count);
void (*AddTechTokens)(void *instance, int count);
void (*AddRaidboxBoxAmount)(void *instance, int count);
void (*AddMonkeyEventTokensFromIAP)(void *instance, int count);
void (*AddReforgeStone)(void *instance, int count);
void (*AddInstantForgeStone)(void *instance, int count);
void (*MisionLevel)(void *instance, int count);
void (*AddBoostItems)(void *instance, int count);
void (*AddBoostItemTrial)(void *instance, bool boolean);
void (*GetValueBoostItem)(void *instance, int count);
void (*AddFragments)(void *instance, int count);
void (*AddCharm)(void *instance, int count);
void (*UpdateDroneNormal)(void *instance, int count);
void (*UpdateDroneSpecial)(void *instance, int count);
void (*set_XP)(void *instance, int count);
void (*AddGrenades)(void *instance, int count);
void (*AddAidKit)(void *instance, int count);
void (*NormalBox)(void *instance, int count);
void (*VipBox)(void *instance, int count);
void (*HQBox)(void *instance, int count);
void (*HOWBox)(void *instance, int count);
void (*CybernetikBox)(void *instance, int count);
void (*AddRedeemEventKey)(void *instance, int count);
void (*AddRedeemEventToken)(void *instance, int count);
void (*AddPurchaseCount)(void *instance, int count);

void (*SetBoughtAllPackInPromoType)(void *instance, bool boolean);
void (*UnlockAllGuns)(void *instance, bool boolean);
void (*UnlockAllGunSkins)(void *instance, bool boolean);
void (*UnlockAllGloves)(void *instance, bool boolean);
void (*UnlockDrone)(void *instance, bool boolean);
void (*PaidUser)(void *instance, bool boolean);
void (*PiggyBankUnlock)(void *instance, bool boolean);
void (*CMIsActive)(void *instance, bool boolean);
void (*ActiveBoostBonus)(void *instance, bool boolean);
void (*BattlePassUS)(void *instance, bool boolean);
void (*InterstitalAdsV5)(void *instance, bool boolean);
void (*Subscription)(void *instance, bool boolean);
void (*ForceFree2Paid)(void *instance, bool boolean);
void (*old_UpdateMoney)(void *instance);
void UpdateMoney(void *instance){
        if (instance != NULL){
         if (isMoney){
          AddGameMoney(instance, 99999999); // value
          }
         if (isPayMoney){
          AddPayMoney(instance, 99999999); // value
          }
         if (isDiamond){
          AddDiamond(instance, 99999999); // value
          }
         if (isSkinPart){
          AddSkinPart(instance, 1000); // value
          AddSkinPartVisual(instance, 1000); // value
          }
         if (isLazyToken){
          AddLazyEventTokens(instance, 1000); // value
          }
         if (isModuleToken){
          AddGunModuleTokens(instance, 999999); // value
          }
         if (isTechToken){
          AddTechTokens(instance, 999999); // value
          }
         if (isRaidBox){
          AddRaidboxBoxAmount(instance, 1000); // value
          }
         if (isMonkeyToken){
          AddMonkeyEventTokensFromIAP(instance, 10000); // value
          }
         if (isReforgeStone){
          AddReforgeStone(instance, 1000); // value
          AddInstantForgeStone(instance, 1000); // value
          }
         if (isBosstItem){
          AddBoostItems(instance, 10); // value
          }
         if (isAddBoostItemTrial){
          AddBoostItemTrial(instance, true); // value
          }
         if (isGetValueBoostItem){
          GetValueBoostItem(instance, 10); // value
          }
         if (isFragments){
          AddFragments(instance, 10000000); // value
          }
         if (isAddCharm){
          AddCharm(instance, 1000); // value
          }
         if (isDronePartN){
          UpdateDroneNormal(instance, 100); // value
          }
         if (isDronePartS){
          UpdateDroneSpecial(instance, 100); // value
          }
         if (isNormalBox){
          NormalBox(instance, 5); // value
          }
         if (isVipBox){
          VipBox(instance, 5); // value
          }
         if (isHQBox){
          HQBox(instance, 5); // value
          }
         if (isHOWBox){
          HOWBox(instance, 5); // value
          }
         if (isCybernetikBox){
          CybernetikBox(instance, 5); // value
          }
         if (isMision){
          MisionLevel(instance, 999999999); // value
          }
         if (isRedeemKey){
          AddRedeemEventKey(instance, 1000); // value
          }
         if (isRedeemToken){
          AddRedeemEventToken(instance, 1000); // value
          }
         if (isPurchase){
          AddPurchaseCount(instance, 2000000000); // value
          }
         if (isBuyAllPack){
          SetBoughtAllPackInPromoType(instance, true); // value
          }
          if (isEXP){
          set_XP(instance, 100000000); // value
          }
          if (isGrande){
          AddGrenades(instance, 10); // value
          }
          if (isAidKit){
          AddAidKit(instance, 10); // value
          }
         if (isUnlockAllGuns){
          UnlockAllGuns(instance, true); // value
          }
         if (isUnlockAllSkin){
          UnlockAllGunSkins(instance, true); // value
          }
         if (isUnlockAllGlove){
          UnlockAllGloves(instance, true); // value
          }
         if (isUnlockDrone){
          UnlockDrone(instance, true); // value
          }
         if (isPaidUser){
          ForceFree2Paid(instance, true); // value
          }
         if (isInterstitalAdsV5){
          InterstitalAdsV5(instance, false); // value
          }
         if (isCheat) {
          *(bool *) ((uint64_t) instance + isUseCheat) = false;
          *(bool *) ((uint64_t) instance + isUseCheatEndlessBoostRewardRating) = false;
          *(bool *) ((uint64_t) instance + isAccountAllowCheat) = false;
          *(bool *) ((uint64_t) instance + isCheatForceOverHeat) = false;
          *(bool *) ((uint64_t) instance + useCheatSaveMission) = false;
          }
         if (iscritRate) {
          *(float *) ((uint64_t) instance + critRate) = 10000;
          }
         if (isboost) {
          *(bool *) ((uint64_t) instance + _activeBoostBonus) = true;
          *(bool *) ((uint64_t) instance + isRemoveBoostDamage) = false;
          }
     }
     return old_UpdateMoney(instance);
}

bool (*oBooleanTrue)(void *Jek);
bool BooleanTrue(void *Jek) {
    if (Jek !=NULL) {
    return true;
    }
}

bool (*old_UnlockAllMode)(void*instance);
bool UnlockAllMode(void*instance){
    if(instance != NULL){
        if(isUnlockAllMode){
         return true;
        }
    }
    return old_UnlockAllMode(instance);
}

void (*HatchAllEggs)(void *instance, bool boolean);
void (*AutoFindTarget)(void *instance, bool boolean);
void (*Win)(void *instance, bool boolean);
void (*KillAllZombieServant)(void *instance, bool boolean);
void (*StopAllSpawnZombieCoroutine)(void *instance, bool boolean);
void (*SpawnMascot)(void *instance, int count);
void (*IncreaseCurrentWave)(void *instance, int count);
void (*AddTotalReward)(void *instance, int count);

void (*old_UpdateGamePlay)(void *instance);
      void UpdateGamePlay(void *instance){
      if (instance != NULL){
         if (isHatchAllEggs){
          HatchAllEggs(instance, true);
          }
         if (isAutoFindTarget){
          AutoFindTarget(instance, true);
          }
         if (isWin){
          Win(instance, true);
          }
         if (isKillAllZombieServant){
          KillAllZombieServant(instance, true);
          }
         if (isStopAllSpawnZombieCoroutine){
          StopAllSpawnZombieCoroutine(instance, true);
          }
         if (isSpawnMascot){
          SpawnMascot(instance, 100);
          }
         if (isIncreaseCurrentWave){
          IncreaseCurrentWave(instance, 99);
          }
         if (isAddTotalReward){
          AddTotalReward(instance, 1000000);
          }
          if (isFps) {
          *(int *)((uint64_t)instance + minMissionFPS) = 120;
          *(int *)((uint64_t)instance + maxMissionFPS) = 120;
          *(int *)((uint64_t)instance + frameCount) = 120;
          *(float *)((uint64_t)instance + currentFPS) = 120;
          }
      }
     return old_UpdateGamePlay(instance);
}

bool isBattlePass;
void (*BuyBattlePassNU)(void *Jek, bool boolean);
void (*BuyBattlePass35)(void *Jek, bool boolean);
void (*BuyBattlePass)(void *Jek, bool boolean);
void (*OnPurchaseFailed)(void *Jek, bool boolean);
void (*PurchaseFailedHandle)(void *Jek, bool boolean);
#define isRequestPayloadTimeout Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController") , OBFUSCATE("isRequestPayloadTimeout"))
#define isPaymentTimeout Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController") , OBFUSCATE("isPaymentTimeout"))
#define waitingRestorePurchase Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("PaymentController") , OBFUSCATE("waitingRestorePurchase"))
void (*_UpdatePayment)(void *Jek);
void UpdatePayment(void *Jek) {
    if (Jek !=NULL) {
        if (isBattlePass) {
        BuyBattlePassNU(Jek, true);
        BuyBattlePass35(Jek, true);
        BuyBattlePass(Jek, true);
        OnPurchaseFailed(Jek, false);
        PurchaseFailedHandle(Jek, false);
        *(bool *)((uint64_t)Jek + isRequestPayloadTimeout) = false;
        *(bool *)((uint64_t)Jek + isPaymentTimeout) = false;
        *(bool *)((uint64_t)Jek + waitingRestorePurchase) = false;
        }
    }
    return _UpdatePayment(Jek);
}

bool (*oUnlockDronePage)(void *Jek);
bool UnlockDronePage(void *Jek) {
    if (Jek !=NULL) {
        if (isUnlockDrone) {
        return true;
        }
    }
    return oUnlockDronePage(Jek);
}



float (*oHeadShotPercent)(void*instance);
float HeadShotPercent(void*instance){
    if(instance != NULL){
        if(isAutoFindTarget){
         return 500;
        }
    }
    return oHeadShotPercent(instance);
}

int (*old_Ammo)(void*instance);
int Ammo(void*instance){
    if(instance != NULL){
        if(isAmmo){
         return 9999;
        }
    }
    return old_Ammo(instance);
}

int (*old_Damage)(void*instance);
int Damage(void*instance){
    if(instance != NULL){
        if(isDamage){
         return 1000000000000000;
        }
    }
    return old_Damage(instance);
}

bool (*old_reload)(void*instance);
bool reload(void*instance){
    if(instance != NULL){
        if(isreload){
         return true;
        }
    }
    return old_reload(instance);
}

bool (*old_Buff)(void*instance);
bool Buff(void*instance){
    if(instance != NULL){
        if(isBuff){
         return true;
        }
    }
    return old_Buff(instance);
}

bool (*old_OtherBuff)(void*instance);
bool OtherBuff(void*instance){
    if(instance != NULL){
        if(isOtherBuff){
         return true;
        }
    }
    return old_OtherBuff(instance);
}

bool (*old_UseBuff)(void*instance);
bool UseBuff(void*instance){
    if(instance != NULL){
        if(isUseBuff){
         return true;
        }
    }
    return old_UseBuff(instance);
}

bool (*old_Rage)(void*instance);
bool Rage(void*instance){
    if(instance != NULL){
        if(isRage){
         return true;
        }
    }
    return old_Rage(instance);
}

bool (*old_DroneActive)(void*instance);
bool DroneActive(void*instance){
    if(instance != NULL){
        if(isDroneActive){
         return true;
        }
    }
    return old_DroneActive(instance);
}

void (*orig_GameNoAds)(...);
void GameNoAds()
{      
    return orig_GameNoAds();
}

bool isNoAds,isNoAds1,isNoAds2 = true;
bool (*get_NoAds)(void*instance);
bool NoAds(void*instance){
    if(instance != NULL){
        if(isNoAds){
         return false;
        }
    }
    return get_NoAds(instance);
}
bool (*get_NoAds1)(void*instance);
bool NoAds1(void*instance){
    if(instance != NULL){
        if(isNoAds1){
         return false;
        }
    }
    return get_NoAds1(instance);
}
bool (*get_NoAds2)(void*instance);
bool NoAds2(void*instance){
    if(instance != NULL){
        if(isNoAds2){
         return false;
        }
    }
    return get_NoAds2(instance);
}



