#pragma once
#ifndef IMGUIANDROID_FUNCTIONPOINTERS_H
#define IMGUIANDROID_FUNCTIONPOINTERS_H

#define GetZombieHealth (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_CurTotalHP", 0)
#define GetZombieMaxHealth (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_TotalHP", 0)
#define headScale Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase"), OBFUSCATE("headScale"))


namespace Pointers
{
    void *(*Component_get_transform)(void *instance);
    Vector3 (*Transform_get_position)(void *instance);
    void *(*Transform_set_localScale)(void *instance, Vector3 Scale);
    void *(*Transform_set_position)(void *instance, Vector3 Pos);
    void *(*Transform_set_rotation)(void *instance, Quaternion Ros);
    Vector3 (*Camera_WorldToScreenPoint)(void *instance, Vector3 worldPosition);
    //void *(*CameraManager_get_MainCamera)() = NULL;
    void *(*Camera_get_main)() = NULL;
    void *(*Camera_get_current)() = NULL;
    bool *(*Object_IsNativeObjectAlive)(void *object) = NULL;
    
	void (*Screen_SetResolution)(int width, int height, bool fullscreen);
	
	bool (*get_isDead)(void *instance);
    int (*MinHealth)(void *instance);
    int (*MaxHealth)(void *instance);
    MonoString* (*GetName)(void *player);
   // void *(*Enemy_RootTransform)(void* instance);
    //Vector3 (*Player_get_Position)(void *instance);
    
    void LoadPointers()
    {
    Component_get_transform = *(void *(*)(void *)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Component", "get_transform", 0);
    Transform_get_position = *(Vector3 (*)(void *)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "get_position", 0);
    Transform_set_position = *(void *(*)(void *, Vector3)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "set_position", 1);
    Transform_set_localScale = *(void *(*)(void *, Vector3)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "set_localScale", 1);
    Transform_set_rotation = *(void *(*)(void *, Quaternion)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Transform", "set_rotation", 1);
    Camera_WorldToScreenPoint = *(Vector3 (*)(void *, Vector3)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);     
    Camera_get_main = *(void *(*)()) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_main", 0);
	Camera_get_current = (void *(*)()) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_current", 0);
    //CameraManager_get_MainCamera = (void *(*)()) (uintptr_t) Il2CppGetMethodOffset("WalkingZombie.dll", "WalkingZombie", "CFirstPersonCamera", "get_FirstPersonCamera", 0);
    Object_IsNativeObjectAlive = (bool *(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Object", "IsNativeObjectAlive", 1);  
    
    Screen_SetResolution = (void (*)(int, int, bool)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Screen", "SetResolution", 3);
    
    get_isDead = *(bool (*)(void *)) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "isDead", 0);
    MinHealth = *(int (*)(void *)) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_CurTotalHP", 0);
    MaxHealth = *(int (*)(void *)) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_TotalHP", 0);
    GetName = *(MonoString *(*)(void *)) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_nameZombie", 0);
    //Enemy_RootTransform = *(void *(*)(void *)) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_RootTransform", 0);
   //Player_get_Position = *(Vector3 (*)(void *)) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_Position", 0);
   }
}

string float_to_string (int value) 
{
    string str; 
    str = std::to_string(value);
    str += "M";
    return str;
}

long GetMaxHealth(void *player) {
    return reinterpret_cast<long(__fastcall *)(void *)>(Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_TotalHP", 0))(player);
}

long GetCurHealth(void *player) {
    return reinterpret_cast<long(__fastcall *)(void *)>(Il2CppGetMethodOffset("Assembly-CSharp.dll", "DProject", "ZombieBase", "get_CurTotalHP", 0))(player);
}

int GetMaxPlayerHealth(void *player) {
    return *(int *) ((uint64_t) player + Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase"), OBFUSCATE("_curTotalHP"))); 
}

bool PlayerAlive(void *player) {
    return player != NULL && Pointers::get_isDead(player) > 0;
}

bool IsPlayerDead(void *player) {
    return player == NULL && Pointers::get_isDead(player) < 1;
}


MonoStrings *GetNames(void *player) {
    return *(MonoStrings *) ((uint64_t) player + Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase"), OBFUSCATE("<nameZombie>k__BackingField"))); 
}

Vector3 ZombiePos(void *player) {
   return *(Vector3 *) ((uint64_t) player + Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase"), OBFUSCATE("zombieStartPos"))); 
}
/*
Vector3 headScale(void *player) {
   return *(Vector3 *) ((uint64_t) player + Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("ZombieBase"), OBFUSCATE("headScale"))); 
}*/

#endif IMGUIANDROID_FUNCTIONPOINTERS_H
