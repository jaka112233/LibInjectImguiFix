//Structure//

std::vector<void *> entitys;

bool entityFind(void *ent) {
    if (ent != NULL) {
        for (int i = 0; i < entitys.size(); i++) { //looped//
            if (ent == entitys[i]) return true;
        }
    }
    return false;
}
