#pragma once

#include <malloc.h>
#include <errno.h>
#include <stdarg.h>

using namespace Pointers;
Vector3 GetPlayerPosition(void *player) {
   return Transform_get_position(Component_get_transform(player));
}

bool m_CachedPtr(void *unity_obj) {
     return (unity_obj != nullptr && (*(uintptr_t*)((uintptr_t)unity_obj + 0x10))); //class Object -> private IntPtr m_CachedPtr; // 0x8
}

void *camera = NULL;

void DrawESP(ImDrawList *draw, int screenWidth, int screenHeight) {
        
   if (!bInitDone) return;
   /*
    std::string players;
    players += "[ Zombie Alive : ";
    players += std::to_string((intptr_t) entitys.size());
    players += " ]";
    Drawing::DrawText(30.0f, ImVec2(screenWidth / 2, screenHeight / 10), ImVec4(255, 0, 0, 255), players.c_str());
    */
        int totalEnemies = 0;
		//int totalBots = 0;
		char extra[50];
		
    if (EnableEsp) {
    
     for (int i = 0; i < entitys.size(); i++) {       
        void *Player = entitys[i];
           if(Camera_get_main != nullptr) {
              if (Player != nullptr) {    
              void *Camera =  Camera_get_main();
       
        if(Screen_SetResolution != NULL) {
            Screen_SetResolution(screenWidth, screenHeight, true);    
        }
          
        if(Camera_get_current != NULL) {
            camera = Camera_get_current();
        }
        if(Camera_get_main() != NULL) {
            camera = Camera_get_main(); 
        }
        
        int is_NameColors;
		long is_Color;
		long is_ColorFilled;     
	    
        if(Player != NULL && Object_IsNativeObjectAlive(Player) && Tools::IsPtrValid(Player) && camera != NULL && m_CachedPtr(Player)) {
          
            is_Color = ImColor(255, 255, 255, 255);
            is_ColorFilled = ImColor(255, 0, 0, 60);
            is_NameColors = ImColor(255, 255, 100, 255);
			totalEnemies++;
            
          Vector3 HeadPosition = {GetPlayerPosition(Player).X, GetPlayerPosition(Player).Y + 2.0f, GetPlayerPosition(Player).Z};
          Vector3 FixedHeadPosition = Camera_WorldToScreenPoint(Camera, HeadPosition);
          if (FixedHeadPosition.Z < 1.0f) continue;
                    
          Vector3 RootPosition = {GetPlayerPosition(Player).X, GetPlayerPosition(Player).Y + 0.2f, GetPlayerPosition(Player).Z};
          Vector3 FixedRootPosition = Camera_WorldToScreenPoint(Camera, RootPosition);
          if (FixedRootPosition.Z < 1.0f) continue;
          
          Vector3 Me = Transform_get_position(Component_get_transform(Camera));
          Vector3 FixMe = {Me.X, Me.Y, Me.Z};
         // if (FixMe.Z < 1.0f) continue;
          
          auto distance = Vector3::Distance(Me, GetPlayerPosition(Player));
          
          float Hight = abs(FixedHeadPosition.Y - FixedRootPosition.Y) * (1.0 / 1.0), Width = Hight * 0.60f;
          Rect rect = {FixedHeadPosition.X - Width / 2.0f, screenHeight - FixedHeadPosition.Y, Width, Hight};

          ImVec2 FromScreen = ImVec2(screenWidth / 2, screenHeight / 10);
          ImVec2 ToPosition = ImVec2((screenWidth- (screenWidth - FixedHeadPosition.X)), (screenHeight - FixedHeadPosition.Y));
              
           if(isESPLine) {
             draw->AddLine(FromScreen, ToPosition, ImColor(255,0,226,255), 1.5f);  
           }
           
           if (EspLine2) {
            if (FixedHeadPosition.Z >= 1.0f) {
                ImU32 lineColorU32 = ImGui::GetColorU32(lineColor);
                ImU32 outlineColorU32 = ImGui::GetColorU32(outlineColor);
                float outlineThickness = lineThickness + 1.0f;
                draw->AddLine(ImVec2(screenWidth / 2, 0), ImVec2(FixedHeadPosition.X, screenHeight - FixedHeadPosition.Y), outlineColorU32, outlineThickness);
                draw->AddLine(ImVec2(screenWidth / 2, 0), ImVec2(FixedHeadPosition.X, screenHeight - FixedHeadPosition.Y), lineColorU32, lineThickness);
                }
			}
          
           if(isESPBox) {
              Drawing::DrawBox(rect, 1.5f, ImColor(255,0,255,16)); 
           }
		   
           if(isESPCornerBox) {
              Drawing::DrawCornerBox(ImColor(255,0,255,16), 1.5f, rect); 
           }
		   
		   if(isEspHp) {
		   long Health = GetCurHealth(Player);
		   int FixHealth = Health;
			std::string hp;
            hp += "[ HP : ";
            hp += std::to_string((intptr_t) FixHealth);
            hp += " ]";
		    //draw->AddText(ImVec2(rect.x + (rect.width / 2),rect.y + rect.height + 12.0f), ImColor(255,255,0,0), hp.c_str());
            draw->AddText(nullptr, 18, ImVec2(FixedHeadPosition.X - 45.0f, screenHeight - FixedHeadPosition.Y - 27.0f), ImColor(0, 0, 0, 255), hp.c_str());
            draw->AddText(nullptr, 18, ImVec2(FixedHeadPosition.X - 45.0f, screenHeight - FixedHeadPosition.Y - 27.0f), ImColor(225, 225, 225, 255), hp.c_str());       
			}
		   
           if(isEspHealth) {
           long CurHP = GetCurHealth(Player);
           int FixCurHP = CurHP;
           long MaxHP = GetMaxHealth(Player);
           int FixMaxHP = MaxHP;
           Drawing::DrawCircleHealth(ImVec2(FixedHeadPosition.X, screenHeight - FixedHeadPosition.Y), FixCurHP, FixMaxHP, 15.0f);
            }
            
            
            if(isESPName) {              
            MonoString* isName = GetName(Player);
            char nick[0xFF] = {0};
		    snprintf(nick,sizeof(nick), OBFUSCATE("%s"), isName->CString());
            draw->AddText(ImVec2(rect.x + (rect.width / 2),rect.y + rect.height + 11.0f), ImColor(255,255,255,255), nick);   
            }
                                            
            
            if (isEspDistance) {
            char extra[30];                
            auto distance = Vector3::Distance(GetPlayerPosition(Component_get_transform(Camera)),GetPlayerPosition(Player));  
            sprintf(extra, "%0.0f m", distance);          
            Drawing::DrawText(25, ImVec2(rect.x + (rect.width / 2),rect.y + rect.height + 10.0f), ImColor(255,255,255,255), extra);   
            }
            
            if (TeleKill) {
            Vector3 enemy_position = GetPlayerPosition(Player);
            Transform_set_position(Component_get_transform(Camera), Vector3(enemy_position.X, enemy_position.Y, enemy_position.Z + 1));
            }
            if (Fly && YAxis > 1) {
            Vector3 MyPos = Transform_get_position(Component_get_transform(Camera));
            Transform_set_position(Component_get_transform(Camera), Vector3(MyPos.X, MyPos.Y = (float) YAxis, MyPos.Z));
            }
          }
        }
      }
    }
    draw->AddRectFilled({glWidth / 2 - 50, 40}, {glWidth / 2, 80}, ImColor(255, 0, 0, 110));
	//draw->AddRectFilled({glWidth / 2 + 50, 40}, {glWidth / 2, 80}, ImColor(3, 255, 40, 110));
	
	//Player
	sprintf(extra, OBFUSCATE("%d"), totalEnemies);
	draw->AddText({glWidth / 2 - 35, 45}, ImColor(255,255,255), extra);
	/*
	//Bots
	sprintf(extra, OBFUSCATE("%d"), totalBots);
	draw->AddText({glWidth / 2 + 15, 45}, ImColor(255,255,255), extra);*/
  }
}
