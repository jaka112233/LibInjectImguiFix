// credit : @NEXTJEK

void (*org_NewDetectionSystem)(...);
void new_DetectionSystem()
{
    return new_DetectionSystem();
}

bool (*_Bypass_AntiCheat_)(void *Jek);
bool Bypass_AntiCheat_(void *Jek) {
    return false;
}

void initByps() {
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ConfigEndlessRewardRandom") , OBFUSCATE("CheatBoostReward"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("LetsBuildEventController") , OBFUSCATE("set_cheatProductId"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("LetsBuildEventController") , OBFUSCATE("set_cheatBattleInfoId"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("MysteryEventController") , OBFUSCATE("CheatReset"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("MysteryEventController") , OBFUSCATE("CheatDeleteOwnedSkin"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("TreasureHuntingEventController") , OBFUSCATE("CheatRound"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("TreasureHuntingEventController") , OBFUSCATE("CheatEventCode"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("TreasureHuntingScenarioManager") , OBFUSCATE("CheatResolveCurrentScenario"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("CrossbowPVPScoreSystem") , OBFUSCATE("CheatScore"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ControlGloveSkin") , OBFUSCATE("BtnDel_Cheat_OnClick"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("ControlGloveSkin") , OBFUSCATE("BtnGet_Cheat_OnClick"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("EventGunTrial") , OBFUSCATE("UpdateCheatStatus"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("UAConversionDataMng") , OBFUSCATE("CheatPropertiesForSegmentLTV"), 3), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("UAConversionDataMng") , OBFUSCATE("CampaignLTV_StartCheck4Cheat"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("TrackingManager") , OBFUSCATE("CheckingCheatingUser"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("EndlessHelper") , OBFUSCATE("CheatStartWave"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("MiniEventBoxController") , OBFUSCATE("CheatProgression"), 2), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("CheatEndCurrentWave"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("CheatNextRewardEndless"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("Gameplay") , OBFUSCATE("CheatEndlessBoostRewardRating"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("MissionRaceController") , OBFUSCATE("CheatTime"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("MissionRaceController") , OBFUSCATE("CheatRank"), 2), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("MainUIEvent") , OBFUSCATE("UpdateCheatBoostRewardEndlessLabel"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("CrossbowPvpShopView") , OBFUSCATE("CheatToken"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("QuestView") , OBFUSCATE("OnBtnCheatRankClick"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("QuestView") , OBFUSCATE("CheatUpLevel"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("RedeemEventController") , OBFUSCATE("CheatCurrentIndex"), 1), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("SupplyRushEventController") , OBFUSCATE("ResetDataCheat"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("WeaponSkinView") , OBFUSCATE("CheatGetSkin"), 0), (void *) new_DetectionSystem, (void **) &org_NewDetectionSystem);
	
	
	Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("FastPlay") , OBFUSCATE("get_isCheatAchievement")), (void *) Bypass_AntiCheat_, (void **) &_Bypass_AntiCheat_);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("TrackingManager") , OBFUSCATE("maybeCheatUser_ReceiveGolds")), (void *) Bypass_AntiCheat_, (void **) &_Bypass_AntiCheat_);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("UserData") , OBFUSCATE("IsNewUserBPEmail1CheatEnabled")), (void *) Bypass_AntiCheat_, (void **) &_Bypass_AntiCheat_);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE(""), OBFUSCATE("UserData") , OBFUSCATE("IsNewUserBPEmail2CheatEnabled")), (void *) Bypass_AntiCheat_, (void **) &_Bypass_AntiCheat_);
    Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("DProject"), OBFUSCATE("InventoryBoostCtrl") , OBFUSCATE("isCheat"), 2), (void *) Bypass_AntiCheat_, (void **) &_Bypass_AntiCheat_);
    
}
