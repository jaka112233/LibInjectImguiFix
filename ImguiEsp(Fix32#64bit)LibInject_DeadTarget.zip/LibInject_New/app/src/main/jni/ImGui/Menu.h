#pragma once

namespace Menu
{
    void ImAim(int x, int y)
    {

    }
    void Render()
    {
        //Move To Main.cpp
    }
}